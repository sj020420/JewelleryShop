import { useState } from 'react';
import { FaChevronDown } from 'react-icons/fa';

const faqs = [
  { q: 'Do you offer online payment?', a: 'No, we do not process online payments. When you click "Buy Now", you will be connected directly with us on WhatsApp to discuss your purchase and complete it in-store.' },
  { q: 'Is your gold hallmark certified?', a: 'Yes, all our gold jewellery is hallmark certified for guaranteed purity.' },
  { q: 'Can I customize a design?', a: 'Absolutely. Reach out to us on WhatsApp or visit our store to discuss custom designs.' },
  { q: 'Do you provide a warranty or exchange?', a: 'Yes, please ask our team in-store about our exchange and warranty policy for your specific purchase.' },
  { q: 'How do I check the price of an item?', a: 'Prices are listed on each product page and update with the latest gold/diamond rates. For exact quotes, contact us on WhatsApp.' },
];

export default function FAQ() {
  const [open, setOpen] = useState(null);

  return (
    <div className="container-shop py-16 max-w-2xl mx-auto">
      <div className="text-center mb-10">
        <h1 className="font-display text-3xl md:text-4xl text-ink">Frequently Asked Questions</h1>
        <div className="chain-divider mt-4"><span /><span /><span /><span /><span /></div>
      </div>
      <div className="space-y-3">
        {faqs.map((f, i) => (
          <div key={i} className="border border-gold/20 rounded-xl overflow-hidden">
            <button
              onClick={() => setOpen(open === i ? null : i)}
              className="w-full flex items-center justify-between px-5 py-4 text-left"
            >
              <span className="font-display text-lg text-ink">{f.q}</span>
              <FaChevronDown className={`text-gold-dark transition-transform ${open === i ? 'rotate-180' : ''}`} size={13} />
            </button>
            {open === i && <p className="px-5 pb-4 text-sm text-ink/60">{f.a}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
